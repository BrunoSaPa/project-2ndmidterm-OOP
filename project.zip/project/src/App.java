public class App {
    public static void main(String[] args) {
        AppMenuGUI app = new AppMenuGUI();
    }
}