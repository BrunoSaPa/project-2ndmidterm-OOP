public interface Statistics {
    public void increasePuntuacionTotal();
    public void increaseTurnosJugados();
    public void increaseJuegosGanados();
    public void increaseJuegosJugados();   
}
